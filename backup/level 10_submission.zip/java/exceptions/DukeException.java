//level 7.more oop

package exceptions;

public class DukeException extends Exception {



}
