public class DukeException extends Exception {

}