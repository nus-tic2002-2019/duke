package exception;
/**
 *Represents the Duke Exception whenever there is an exception handling.
 * */
public class DukeException extends Exception {
    public DukeException(String message) {
        super(message);
    }
}
